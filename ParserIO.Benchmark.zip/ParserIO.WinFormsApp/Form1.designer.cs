﻿namespace ParserIO.WinFormsApp
{
  partial class Form1
  {
    /// <summary>
    /// Variable nécessaire au concepteur.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Nettoyage des ressources utilisées.
    /// </summary>
    /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Code généré par le Concepteur Windows Form

    /// <summary>
    /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
    /// le contenu de cette méthode avec l'éditeur de code.
    /// </summary>
    private void InitializeComponent()
    {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxBarcode = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxType = new System.Windows.Forms.TextBox();
            this.textBoxVariante = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxUPN = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.textBoxUoM = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxPCN = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxLIC = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxLot = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxExpiry = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxNormalizedExpiry = new System.Windows.Forms.TextBox();
            this.buttonParser = new System.Windows.Forms.Button();
            this.textBoxReference = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxQuantity = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBoxSerial = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.testToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutParserIOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxACL = new System.Windows.Forms.TextBox();
            this.ACL = new System.Windows.Forms.Label();
            this.textBoxFamily = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.textBoxLPP = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBoxCIP = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.textBoxNaS7 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.labelContainsProductId = new System.Windows.Forms.Label();
            this.textBoxcontainsOrMayContainId = new System.Windows.Forms.TextBox();
            this.textBoxSymbologyID = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBoxNaSIdParamName = new System.Windows.Forms.TextBox();
            this.labelNaSIdParamName = new System.Windows.Forms.Label();
            this.textBoxUDI = new System.Windows.Forms.TextBox();
            this.labelUDI = new System.Windows.Forms.Label();
            this.textBoxExecuteResult = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.textBoxAdditionalInformation = new System.Windows.Forms.TextBox();
            this.labelAdditionalInformation = new System.Windows.Forms.Label();
            this.textBoxStorageLocation = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tabControlOutput = new System.Windows.Forms.TabControl();
            this.hibcTabPage = new System.Windows.Forms.TabPage();
            this.gs1TabPage = new System.Windows.Forms.TabPage();
            this.textBoxCUSTPARTNO = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.textBoxEAN = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBoxINTERNAL_99 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBoxINTERNAL_98 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBoxINTERNAL_97 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBoxINTERNAL_96 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.textBoxINTERNAL_95 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textBoxINTERNAL_94 = new System.Windows.Forms.TextBox();
            this.textBoxPRODDATE = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.textBoxINTERNAL_93 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.textBoxINTERNAL_92 = new System.Windows.Forms.TextBox();
            this.textBoxNormalizedPRODDATE = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxINTERNAL_91 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxADDITIONALID = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.textBoxVARIANT = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.textBoxBESTBEFORE = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBoxCOUNT = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxNormalizedBESTBEFORE = new System.Windows.Forms.TextBox();
            this.textBoxVARCOUNT = new System.Windows.Forms.TextBox();
            this.textBoxCONTENT = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxSSCC = new System.Windows.Forms.TextBox();
            this.textBoxGTIN = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.nasTabPage = new System.Windows.Forms.TabPage();
            this.textBoxIdentifiers = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.textBoxParserIOVersion = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabControlOutput.SuspendLayout();
            this.hibcTabPage.SuspendLayout();
            this.gs1TabPage.SuspendLayout();
            this.nasTabPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Barcode";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxBarcode
            // 
            this.textBoxBarcode.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.textBoxBarcode.Location = new System.Drawing.Point(120, 40);
            this.textBoxBarcode.Name = "textBoxBarcode";
            this.textBoxBarcode.Size = new System.Drawing.Size(293, 20);
            this.textBoxBarcode.TabIndex = 1;
            this.textBoxBarcode.TextChanged += new System.EventHandler(this.textBoxCode_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(83, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Type";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxType
            // 
            this.textBoxType.Location = new System.Drawing.Point(121, 149);
            this.textBoxType.Name = "textBoxType";
            this.textBoxType.ReadOnly = true;
            this.textBoxType.Size = new System.Drawing.Size(184, 20);
            this.textBoxType.TabIndex = 3;
            // 
            // textBoxVariante
            // 
            this.textBoxVariante.Location = new System.Drawing.Point(121, 172);
            this.textBoxVariante.Name = "textBoxVariante";
            this.textBoxVariante.ReadOnly = true;
            this.textBoxVariante.Size = new System.Drawing.Size(184, 20);
            this.textBoxVariante.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "SubType";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxUPN
            // 
            this.textBoxUPN.Location = new System.Drawing.Point(126, 94);
            this.textBoxUPN.Name = "textBoxUPN";
            this.textBoxUPN.ReadOnly = true;
            this.textBoxUPN.Size = new System.Drawing.Size(184, 20);
            this.textBoxUPN.TabIndex = 13;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(86, 99);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(30, 13);
            this.label25.TabIndex = 12;
            this.label25.Text = "UPN";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxUoM
            // 
            this.textBoxUoM.Location = new System.Drawing.Point(126, 71);
            this.textBoxUoM.Name = "textBoxUoM";
            this.textBoxUoM.ReadOnly = true;
            this.textBoxUoM.Size = new System.Drawing.Size(184, 20);
            this.textBoxUoM.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(86, 76);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 13);
            this.label12.TabIndex = 10;
            this.label12.Text = "U/M";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxPCN
            // 
            this.textBoxPCN.Location = new System.Drawing.Point(126, 48);
            this.textBoxPCN.Name = "textBoxPCN";
            this.textBoxPCN.ReadOnly = true;
            this.textBoxPCN.Size = new System.Drawing.Size(184, 20);
            this.textBoxPCN.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(86, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "PCN";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxLIC
            // 
            this.textBoxLIC.Location = new System.Drawing.Point(126, 22);
            this.textBoxLIC.Name = "textBoxLIC";
            this.textBoxLIC.ReadOnly = true;
            this.textBoxLIC.Size = new System.Drawing.Size(184, 20);
            this.textBoxLIC.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(93, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "LIC";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxLot
            // 
            this.textBoxLot.Location = new System.Drawing.Point(121, 321);
            this.textBoxLot.Name = "textBoxLot";
            this.textBoxLot.ReadOnly = true;
            this.textBoxLot.Size = new System.Drawing.Size(184, 20);
            this.textBoxLot.TabIndex = 12;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(88, 324);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "Lot";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxExpiry
            // 
            this.textBoxExpiry.Location = new System.Drawing.Point(121, 347);
            this.textBoxExpiry.Name = "textBoxExpiry";
            this.textBoxExpiry.ReadOnly = true;
            this.textBoxExpiry.Size = new System.Drawing.Size(184, 20);
            this.textBoxExpiry.TabIndex = 16;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(75, 350);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 13);
            this.label11.TabIndex = 15;
            this.label11.Text = "Expiry";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxNormalizedExpiry
            // 
            this.textBoxNormalizedExpiry.Location = new System.Drawing.Point(213, 373);
            this.textBoxNormalizedExpiry.Name = "textBoxNormalizedExpiry";
            this.textBoxNormalizedExpiry.ReadOnly = true;
            this.textBoxNormalizedExpiry.Size = new System.Drawing.Size(92, 20);
            this.textBoxNormalizedExpiry.TabIndex = 17;
            // 
            // buttonParser
            // 
            this.buttonParser.Location = new System.Drawing.Point(419, 38);
            this.buttonParser.Name = "buttonParser";
            this.buttonParser.Size = new System.Drawing.Size(75, 23);
            this.buttonParser.TabIndex = 2;
            this.buttonParser.Text = "Parse";
            this.buttonParser.UseVisualStyleBackColor = true;
            this.buttonParser.Click += new System.EventHandler(this.Parse);
            // 
            // textBoxReference
            // 
            this.textBoxReference.Location = new System.Drawing.Point(130, 72);
            this.textBoxReference.Name = "textBoxReference";
            this.textBoxReference.ReadOnly = true;
            this.textBoxReference.Size = new System.Drawing.Size(184, 20);
            this.textBoxReference.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(62, 75);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Reference";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxQuantity
            // 
            this.textBoxQuantity.Location = new System.Drawing.Point(126, 120);
            this.textBoxQuantity.Name = "textBoxQuantity";
            this.textBoxQuantity.ReadOnly = true;
            this.textBoxQuantity.Size = new System.Drawing.Size(184, 20);
            this.textBoxQuantity.TabIndex = 23;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(68, 122);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(46, 13);
            this.label17.TabIndex = 22;
            this.label17.Text = "Quantity";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxSerial
            // 
            this.textBoxSerial.Location = new System.Drawing.Point(121, 403);
            this.textBoxSerial.Name = "textBoxSerial";
            this.textBoxSerial.ReadOnly = true;
            this.textBoxSerial.Size = new System.Drawing.Size(184, 20);
            this.textBoxSerial.TabIndex = 27;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(77, 405);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(33, 13);
            this.label20.TabIndex = 26;
            this.label20.Text = "Serial";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.testToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1131, 24);
            this.menuStrip1.TabIndex = 28;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // testToolStripMenuItem
            // 
            this.testToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.testToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutParserIOToolStripMenuItem});
            this.testToolStripMenuItem.Name = "testToolStripMenuItem";
            this.testToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.testToolStripMenuItem.Text = "Help";
            // 
            // aboutParserIOToolStripMenuItem
            // 
            this.aboutParserIOToolStripMenuItem.Name = "aboutParserIOToolStripMenuItem";
            this.aboutParserIOToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.aboutParserIOToolStripMenuItem.Text = "About ParserIO";
            this.aboutParserIOToolStripMenuItem.Click += new System.EventHandler(this.aboutParserIOToolStripMenuItem_Click);
            // 
            // textBoxACL
            // 
            this.textBoxACL.Location = new System.Drawing.Point(121, 429);
            this.textBoxACL.Name = "textBoxACL";
            this.textBoxACL.ReadOnly = true;
            this.textBoxACL.Size = new System.Drawing.Size(184, 20);
            this.textBoxACL.TabIndex = 30;
            // 
            // ACL
            // 
            this.ACL.AutoSize = true;
            this.ACL.Location = new System.Drawing.Point(83, 431);
            this.ACL.Name = "ACL";
            this.ACL.Size = new System.Drawing.Size(27, 13);
            this.ACL.TabIndex = 29;
            this.ACL.Text = "ACL";
            this.ACL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxFamily
            // 
            this.textBoxFamily.Location = new System.Drawing.Point(121, 455);
            this.textBoxFamily.Name = "textBoxFamily";
            this.textBoxFamily.ReadOnly = true;
            this.textBoxFamily.Size = new System.Drawing.Size(184, 20);
            this.textBoxFamily.TabIndex = 32;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(74, 457);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(36, 13);
            this.label22.TabIndex = 31;
            this.label22.Text = "Family";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxLPP
            // 
            this.textBoxLPP.Location = new System.Drawing.Point(130, 98);
            this.textBoxLPP.Name = "textBoxLPP";
            this.textBoxLPP.ReadOnly = true;
            this.textBoxLPP.Size = new System.Drawing.Size(184, 20);
            this.textBoxLPP.TabIndex = 34;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(92, 100);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(27, 13);
            this.label23.TabIndex = 33;
            this.label23.Text = "LPP";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxCIP
            // 
            this.textBoxCIP.Location = new System.Drawing.Point(121, 481);
            this.textBoxCIP.Name = "textBoxCIP";
            this.textBoxCIP.ReadOnly = true;
            this.textBoxCIP.Size = new System.Drawing.Size(184, 20);
            this.textBoxCIP.TabIndex = 36;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(85, 483);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(24, 13);
            this.label24.TabIndex = 35;
            this.label24.Text = "CIP";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxNaS7
            // 
            this.textBoxNaS7.Location = new System.Drawing.Point(130, 46);
            this.textBoxNaS7.Name = "textBoxNaS7";
            this.textBoxNaS7.ReadOnly = true;
            this.textBoxNaS7.Size = new System.Drawing.Size(184, 20);
            this.textBoxNaS7.TabIndex = 40;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(82, 47);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(34, 13);
            this.label26.TabIndex = 39;
            this.label26.Text = "NaS7";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(75, 376);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(90, 13);
            this.label29.TabIndex = 41;
            this.label29.Text = "Normalized Expiry";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelContainsProductId
            // 
            this.labelContainsProductId.AutoSize = true;
            this.labelContainsProductId.Location = new System.Drawing.Point(325, 176);
            this.labelContainsProductId.Name = "labelContainsProductId";
            this.labelContainsProductId.Size = new System.Drawing.Size(123, 13);
            this.labelContainsProductId.TabIndex = 42;
            this.labelContainsProductId.Text = "containsOrMayContainId";
            // 
            // textBoxcontainsOrMayContainId
            // 
            this.textBoxcontainsOrMayContainId.Location = new System.Drawing.Point(462, 172);
            this.textBoxcontainsOrMayContainId.Name = "textBoxcontainsOrMayContainId";
            this.textBoxcontainsOrMayContainId.ReadOnly = true;
            this.textBoxcontainsOrMayContainId.Size = new System.Drawing.Size(32, 20);
            this.textBoxcontainsOrMayContainId.TabIndex = 43;
            // 
            // textBoxSymbologyID
            // 
            this.textBoxSymbologyID.Location = new System.Drawing.Point(121, 123);
            this.textBoxSymbologyID.Name = "textBoxSymbologyID";
            this.textBoxSymbologyID.ReadOnly = true;
            this.textBoxSymbologyID.Size = new System.Drawing.Size(184, 20);
            this.textBoxSymbologyID.TabIndex = 47;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(48, 125);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(69, 13);
            this.label32.TabIndex = 46;
            this.label32.Text = "SymbologyID";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxNaSIdParamName
            // 
            this.textBoxNaSIdParamName.Location = new System.Drawing.Point(130, 20);
            this.textBoxNaSIdParamName.Name = "textBoxNaSIdParamName";
            this.textBoxNaSIdParamName.ReadOnly = true;
            this.textBoxNaSIdParamName.Size = new System.Drawing.Size(184, 20);
            this.textBoxNaSIdParamName.TabIndex = 49;
            // 
            // labelNaSIdParamName
            // 
            this.labelNaSIdParamName.AutoSize = true;
            this.labelNaSIdParamName.Location = new System.Drawing.Point(12, 25);
            this.labelNaSIdParamName.Name = "labelNaSIdParamName";
            this.labelNaSIdParamName.Size = new System.Drawing.Size(104, 13);
            this.labelNaSIdParamName.TabIndex = 48;
            this.labelNaSIdParamName.Text = "NaS Id Param Name";
            // 
            // textBoxUDI
            // 
            this.textBoxUDI.Location = new System.Drawing.Point(121, 507);
            this.textBoxUDI.Name = "textBoxUDI";
            this.textBoxUDI.ReadOnly = true;
            this.textBoxUDI.Size = new System.Drawing.Size(184, 20);
            this.textBoxUDI.TabIndex = 51;
            // 
            // labelUDI
            // 
            this.labelUDI.AutoSize = true;
            this.labelUDI.Location = new System.Drawing.Point(81, 509);
            this.labelUDI.Name = "labelUDI";
            this.labelUDI.Size = new System.Drawing.Size(26, 13);
            this.labelUDI.TabIndex = 50;
            this.labelUDI.Text = "UDI";
            this.labelUDI.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxExecuteResult
            // 
            this.textBoxExecuteResult.Location = new System.Drawing.Point(121, 94);
            this.textBoxExecuteResult.Name = "textBoxExecuteResult";
            this.textBoxExecuteResult.ReadOnly = true;
            this.textBoxExecuteResult.Size = new System.Drawing.Size(23, 20);
            this.textBoxExecuteResult.TabIndex = 53;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(41, 97);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(75, 13);
            this.label39.TabIndex = 52;
            this.label39.Text = "executeResult";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxAdditionalInformation
            // 
            this.textBoxAdditionalInformation.Location = new System.Drawing.Point(121, 288);
            this.textBoxAdditionalInformation.Name = "textBoxAdditionalInformation";
            this.textBoxAdditionalInformation.ReadOnly = true;
            this.textBoxAdditionalInformation.Size = new System.Drawing.Size(377, 20);
            this.textBoxAdditionalInformation.TabIndex = 55;
            // 
            // labelAdditionalInformation
            // 
            this.labelAdditionalInformation.AutoSize = true;
            this.labelAdditionalInformation.Location = new System.Drawing.Point(9, 291);
            this.labelAdditionalInformation.Name = "labelAdditionalInformation";
            this.labelAdditionalInformation.Size = new System.Drawing.Size(105, 13);
            this.labelAdditionalInformation.TabIndex = 54;
            this.labelAdditionalInformation.Text = "AdditionalInformation";
            this.labelAdditionalInformation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxStorageLocation
            // 
            this.textBoxStorageLocation.Location = new System.Drawing.Point(108, 24);
            this.textBoxStorageLocation.Name = "textBoxStorageLocation";
            this.textBoxStorageLocation.ReadOnly = true;
            this.textBoxStorageLocation.Size = new System.Drawing.Size(184, 20);
            this.textBoxStorageLocation.TabIndex = 57;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(10, 27);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(88, 13);
            this.label40.TabIndex = 56;
            this.label40.Text = "Storage Location";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxStorageLocation);
            this.groupBox1.Controls.Add(this.label40);
            this.groupBox1.Location = new System.Drawing.Point(20, 166);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(300, 82);
            this.groupBox1.TabIndex = 58;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Additional Supplemental Data";
            // 
            // tabControlOutput
            // 
            this.tabControlOutput.Controls.Add(this.hibcTabPage);
            this.tabControlOutput.Controls.Add(this.gs1TabPage);
            this.tabControlOutput.Controls.Add(this.nasTabPage);
            this.tabControlOutput.Location = new System.Drawing.Point(541, 40);
            this.tabControlOutput.Name = "tabControlOutput";
            this.tabControlOutput.SelectedIndex = 0;
            this.tabControlOutput.Size = new System.Drawing.Size(583, 495);
            this.tabControlOutput.TabIndex = 59;
            // 
            // hibcTabPage
            // 
            this.hibcTabPage.Controls.Add(this.textBoxUPN);
            this.hibcTabPage.Controls.Add(this.groupBox1);
            this.hibcTabPage.Controls.Add(this.textBoxLIC);
            this.hibcTabPage.Controls.Add(this.label25);
            this.hibcTabPage.Controls.Add(this.label8);
            this.hibcTabPage.Controls.Add(this.textBoxUoM);
            this.hibcTabPage.Controls.Add(this.label6);
            this.hibcTabPage.Controls.Add(this.label12);
            this.hibcTabPage.Controls.Add(this.textBoxPCN);
            this.hibcTabPage.Controls.Add(this.textBoxQuantity);
            this.hibcTabPage.Controls.Add(this.label17);
            this.hibcTabPage.Location = new System.Drawing.Point(4, 22);
            this.hibcTabPage.Name = "hibcTabPage";
            this.hibcTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.hibcTabPage.Size = new System.Drawing.Size(575, 469);
            this.hibcTabPage.TabIndex = 0;
            this.hibcTabPage.Text = "HIBC";
            this.hibcTabPage.UseVisualStyleBackColor = true;
            // 
            // gs1TabPage
            // 
            this.gs1TabPage.Controls.Add(this.textBoxCUSTPARTNO);
            this.gs1TabPage.Controls.Add(this.label42);
            this.gs1TabPage.Controls.Add(this.textBoxEAN);
            this.gs1TabPage.Controls.Add(this.label41);
            this.gs1TabPage.Controls.Add(this.textBoxINTERNAL_99);
            this.gs1TabPage.Controls.Add(this.label38);
            this.gs1TabPage.Controls.Add(this.textBoxINTERNAL_98);
            this.gs1TabPage.Controls.Add(this.label37);
            this.gs1TabPage.Controls.Add(this.textBoxINTERNAL_97);
            this.gs1TabPage.Controls.Add(this.label36);
            this.gs1TabPage.Controls.Add(this.label28);
            this.gs1TabPage.Controls.Add(this.textBoxINTERNAL_96);
            this.gs1TabPage.Controls.Add(this.label35);
            this.gs1TabPage.Controls.Add(this.textBoxINTERNAL_95);
            this.gs1TabPage.Controls.Add(this.label34);
            this.gs1TabPage.Controls.Add(this.textBoxINTERNAL_94);
            this.gs1TabPage.Controls.Add(this.textBoxPRODDATE);
            this.gs1TabPage.Controls.Add(this.label18);
            this.gs1TabPage.Controls.Add(this.label31);
            this.gs1TabPage.Controls.Add(this.textBoxINTERNAL_93);
            this.gs1TabPage.Controls.Add(this.label33);
            this.gs1TabPage.Controls.Add(this.textBoxINTERNAL_92);
            this.gs1TabPage.Controls.Add(this.textBoxNormalizedPRODDATE);
            this.gs1TabPage.Controls.Add(this.label5);
            this.gs1TabPage.Controls.Add(this.textBoxINTERNAL_91);
            this.gs1TabPage.Controls.Add(this.label4);
            this.gs1TabPage.Controls.Add(this.textBoxADDITIONALID);
            this.gs1TabPage.Controls.Add(this.label30);
            this.gs1TabPage.Controls.Add(this.label27);
            this.gs1TabPage.Controls.Add(this.textBoxVARIANT);
            this.gs1TabPage.Controls.Add(this.label21);
            this.gs1TabPage.Controls.Add(this.textBoxBESTBEFORE);
            this.gs1TabPage.Controls.Add(this.label19);
            this.gs1TabPage.Controls.Add(this.textBoxCOUNT);
            this.gs1TabPage.Controls.Add(this.label16);
            this.gs1TabPage.Controls.Add(this.textBoxNormalizedBESTBEFORE);
            this.gs1TabPage.Controls.Add(this.textBoxVARCOUNT);
            this.gs1TabPage.Controls.Add(this.textBoxCONTENT);
            this.gs1TabPage.Controls.Add(this.label14);
            this.gs1TabPage.Controls.Add(this.textBoxSSCC);
            this.gs1TabPage.Controls.Add(this.textBoxGTIN);
            this.gs1TabPage.Controls.Add(this.label13);
            this.gs1TabPage.Controls.Add(this.label7);
            this.gs1TabPage.Controls.Add(this.label15);
            this.gs1TabPage.Location = new System.Drawing.Point(4, 22);
            this.gs1TabPage.Name = "gs1TabPage";
            this.gs1TabPage.Padding = new System.Windows.Forms.Padding(3);
            this.gs1TabPage.Size = new System.Drawing.Size(575, 469);
            this.gs1TabPage.TabIndex = 1;
            this.gs1TabPage.Text = "GS1";
            this.gs1TabPage.UseVisualStyleBackColor = true;
            // 
            // textBoxCUSTPARTNO
            // 
            this.textBoxCUSTPARTNO.Location = new System.Drawing.Point(111, 302);
            this.textBoxCUSTPARTNO.Name = "textBoxCUSTPARTNO";
            this.textBoxCUSTPARTNO.ReadOnly = true;
            this.textBoxCUSTPARTNO.Size = new System.Drawing.Size(184, 20);
            this.textBoxCUSTPARTNO.TabIndex = 110;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(15, 306);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(93, 13);
            this.label42.TabIndex = 109;
            this.label42.Text = "CUST. PART NO.";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxEAN
            // 
            this.textBoxEAN.Location = new System.Drawing.Point(111, 74);
            this.textBoxEAN.Name = "textBoxEAN";
            this.textBoxEAN.ReadOnly = true;
            this.textBoxEAN.Size = new System.Drawing.Size(184, 20);
            this.textBoxEAN.TabIndex = 108;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(72, 77);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(29, 13);
            this.label41.TabIndex = 107;
            this.label41.Text = "EAN";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxINTERNAL_99
            // 
            this.textBoxINTERNAL_99.Location = new System.Drawing.Point(385, 407);
            this.textBoxINTERNAL_99.Name = "textBoxINTERNAL_99";
            this.textBoxINTERNAL_99.ReadOnly = true;
            this.textBoxINTERNAL_99.Size = new System.Drawing.Size(184, 20);
            this.textBoxINTERNAL_99.TabIndex = 106;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(300, 411);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(76, 13);
            this.label38.TabIndex = 105;
            this.label38.Text = "INTERNAL 99";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxINTERNAL_98
            // 
            this.textBoxINTERNAL_98.Location = new System.Drawing.Point(385, 381);
            this.textBoxINTERNAL_98.Name = "textBoxINTERNAL_98";
            this.textBoxINTERNAL_98.ReadOnly = true;
            this.textBoxINTERNAL_98.Size = new System.Drawing.Size(184, 20);
            this.textBoxINTERNAL_98.TabIndex = 104;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(300, 385);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(76, 13);
            this.label37.TabIndex = 103;
            this.label37.Text = "INTERNAL 98";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxINTERNAL_97
            // 
            this.textBoxINTERNAL_97.Location = new System.Drawing.Point(385, 355);
            this.textBoxINTERNAL_97.Name = "textBoxINTERNAL_97";
            this.textBoxINTERNAL_97.ReadOnly = true;
            this.textBoxINTERNAL_97.Size = new System.Drawing.Size(184, 20);
            this.textBoxINTERNAL_97.TabIndex = 102;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(300, 359);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(76, 13);
            this.label36.TabIndex = 101;
            this.label36.Text = "INTERNAL 97";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(320, 166);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(125, 13);
            this.label28.TabIndex = 86;
            this.label28.Text = "Normalized PROD DATE";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxINTERNAL_96
            // 
            this.textBoxINTERNAL_96.Location = new System.Drawing.Point(385, 329);
            this.textBoxINTERNAL_96.Name = "textBoxINTERNAL_96";
            this.textBoxINTERNAL_96.ReadOnly = true;
            this.textBoxINTERNAL_96.Size = new System.Drawing.Size(184, 20);
            this.textBoxINTERNAL_96.TabIndex = 100;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(300, 333);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(76, 13);
            this.label35.TabIndex = 99;
            this.label35.Text = "INTERNAL 96";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxINTERNAL_95
            // 
            this.textBoxINTERNAL_95.Location = new System.Drawing.Point(111, 432);
            this.textBoxINTERNAL_95.Name = "textBoxINTERNAL_95";
            this.textBoxINTERNAL_95.ReadOnly = true;
            this.textBoxINTERNAL_95.Size = new System.Drawing.Size(184, 20);
            this.textBoxINTERNAL_95.TabIndex = 98;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(26, 436);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(76, 13);
            this.label34.TabIndex = 97;
            this.label34.Text = "INTERNAL 95";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxINTERNAL_94
            // 
            this.textBoxINTERNAL_94.Location = new System.Drawing.Point(111, 406);
            this.textBoxINTERNAL_94.Name = "textBoxINTERNAL_94";
            this.textBoxINTERNAL_94.ReadOnly = true;
            this.textBoxINTERNAL_94.Size = new System.Drawing.Size(184, 20);
            this.textBoxINTERNAL_94.TabIndex = 96;
            // 
            // textBoxPRODDATE
            // 
            this.textBoxPRODDATE.Location = new System.Drawing.Point(111, 163);
            this.textBoxPRODDATE.Name = "textBoxPRODDATE";
            this.textBoxPRODDATE.ReadOnly = true;
            this.textBoxPRODDATE.Size = new System.Drawing.Size(184, 20);
            this.textBoxPRODDATE.TabIndex = 80;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(31, 165);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(70, 13);
            this.label18.TabIndex = 78;
            this.label18.Text = "PROD DATE";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(26, 410);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(76, 13);
            this.label31.TabIndex = 95;
            this.label31.Text = "INTERNAL 94";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxINTERNAL_93
            // 
            this.textBoxINTERNAL_93.Location = new System.Drawing.Point(111, 380);
            this.textBoxINTERNAL_93.Name = "textBoxINTERNAL_93";
            this.textBoxINTERNAL_93.ReadOnly = true;
            this.textBoxINTERNAL_93.Size = new System.Drawing.Size(184, 20);
            this.textBoxINTERNAL_93.TabIndex = 94;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(26, 384);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(76, 13);
            this.label33.TabIndex = 93;
            this.label33.Text = "INTERNAL 93";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxINTERNAL_92
            // 
            this.textBoxINTERNAL_92.Location = new System.Drawing.Point(111, 354);
            this.textBoxINTERNAL_92.Name = "textBoxINTERNAL_92";
            this.textBoxINTERNAL_92.ReadOnly = true;
            this.textBoxINTERNAL_92.Size = new System.Drawing.Size(184, 20);
            this.textBoxINTERNAL_92.TabIndex = 92;
            // 
            // textBoxNormalizedPRODDATE
            // 
            this.textBoxNormalizedPRODDATE.Location = new System.Drawing.Point(462, 163);
            this.textBoxNormalizedPRODDATE.Name = "textBoxNormalizedPRODDATE";
            this.textBoxNormalizedPRODDATE.ReadOnly = true;
            this.textBoxNormalizedPRODDATE.Size = new System.Drawing.Size(92, 20);
            this.textBoxNormalizedPRODDATE.TabIndex = 77;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(26, 358);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 13);
            this.label5.TabIndex = 91;
            this.label5.Text = "INTERNAL 92";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxINTERNAL_91
            // 
            this.textBoxINTERNAL_91.Location = new System.Drawing.Point(111, 328);
            this.textBoxINTERNAL_91.Name = "textBoxINTERNAL_91";
            this.textBoxINTERNAL_91.ReadOnly = true;
            this.textBoxINTERNAL_91.Size = new System.Drawing.Size(184, 20);
            this.textBoxINTERNAL_91.TabIndex = 90;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 332);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 13);
            this.label4.TabIndex = 89;
            this.label4.Text = "INTERNAL 91";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxADDITIONALID
            // 
            this.textBoxADDITIONALID.Location = new System.Drawing.Point(112, 275);
            this.textBoxADDITIONALID.Name = "textBoxADDITIONALID";
            this.textBoxADDITIONALID.ReadOnly = true;
            this.textBoxADDITIONALID.Size = new System.Drawing.Size(184, 20);
            this.textBoxADDITIONALID.TabIndex = 88;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(16, 279);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(86, 13);
            this.label30.TabIndex = 87;
            this.label30.Text = "ADDITIONAL ID";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(320, 134);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(136, 13);
            this.label27.TabIndex = 85;
            this.label27.Text = "Normalized BEST BEFORE";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxVARIANT
            // 
            this.textBoxVARIANT.Location = new System.Drawing.Point(112, 197);
            this.textBoxVARIANT.Name = "textBoxVARIANT";
            this.textBoxVARIANT.ReadOnly = true;
            this.textBoxVARIANT.Size = new System.Drawing.Size(184, 20);
            this.textBoxVARIANT.TabIndex = 84;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(48, 199);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(54, 13);
            this.label21.TabIndex = 83;
            this.label21.Text = "VARIANT";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxBESTBEFORE
            // 
            this.textBoxBESTBEFORE.Location = new System.Drawing.Point(112, 131);
            this.textBoxBESTBEFORE.Name = "textBoxBESTBEFORE";
            this.textBoxBESTBEFORE.ReadOnly = true;
            this.textBoxBESTBEFORE.Size = new System.Drawing.Size(184, 20);
            this.textBoxBESTBEFORE.TabIndex = 82;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(21, 134);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(81, 13);
            this.label19.TabIndex = 81;
            this.label19.Text = "BEST BEFORE";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxCOUNT
            // 
            this.textBoxCOUNT.Location = new System.Drawing.Point(112, 249);
            this.textBoxCOUNT.Name = "textBoxCOUNT";
            this.textBoxCOUNT.ReadOnly = true;
            this.textBoxCOUNT.Size = new System.Drawing.Size(184, 20);
            this.textBoxCOUNT.TabIndex = 76;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(57, 251);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(45, 13);
            this.label16.TabIndex = 75;
            this.label16.Text = "COUNT";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxNormalizedBESTBEFORE
            // 
            this.textBoxNormalizedBESTBEFORE.Location = new System.Drawing.Point(462, 131);
            this.textBoxNormalizedBESTBEFORE.Name = "textBoxNormalizedBESTBEFORE";
            this.textBoxNormalizedBESTBEFORE.ReadOnly = true;
            this.textBoxNormalizedBESTBEFORE.Size = new System.Drawing.Size(92, 20);
            this.textBoxNormalizedBESTBEFORE.TabIndex = 79;
            // 
            // textBoxVARCOUNT
            // 
            this.textBoxVARCOUNT.Location = new System.Drawing.Point(112, 223);
            this.textBoxVARCOUNT.Name = "textBoxVARCOUNT";
            this.textBoxVARCOUNT.ReadOnly = true;
            this.textBoxVARCOUNT.Size = new System.Drawing.Size(184, 20);
            this.textBoxVARCOUNT.TabIndex = 74;
            // 
            // textBoxCONTENT
            // 
            this.textBoxCONTENT.Location = new System.Drawing.Point(112, 102);
            this.textBoxCONTENT.Name = "textBoxCONTENT";
            this.textBoxCONTENT.ReadOnly = true;
            this.textBoxCONTENT.Size = new System.Drawing.Size(184, 20);
            this.textBoxCONTENT.TabIndex = 72;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(43, 105);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 13);
            this.label14.TabIndex = 71;
            this.label14.Text = "CONTENT";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxSSCC
            // 
            this.textBoxSSCC.Location = new System.Drawing.Point(112, 22);
            this.textBoxSSCC.Name = "textBoxSSCC";
            this.textBoxSSCC.ReadOnly = true;
            this.textBoxSSCC.Size = new System.Drawing.Size(184, 20);
            this.textBoxSSCC.TabIndex = 70;
            // 
            // textBoxGTIN
            // 
            this.textBoxGTIN.Location = new System.Drawing.Point(112, 48);
            this.textBoxGTIN.Name = "textBoxGTIN";
            this.textBoxGTIN.ReadOnly = true;
            this.textBoxGTIN.Size = new System.Drawing.Size(184, 20);
            this.textBoxGTIN.TabIndex = 68;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(67, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 13);
            this.label13.TabIndex = 69;
            this.label13.Text = "SSCC";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(69, 48);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 13);
            this.label7.TabIndex = 67;
            this.label7.Text = "GTIN";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(32, 229);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 13);
            this.label15.TabIndex = 73;
            this.label15.Text = "VAR COUNT";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // nasTabPage
            // 
            this.nasTabPage.Controls.Add(this.labelNaSIdParamName);
            this.nasTabPage.Controls.Add(this.textBoxNaSIdParamName);
            this.nasTabPage.Controls.Add(this.label26);
            this.nasTabPage.Controls.Add(this.textBoxNaS7);
            this.nasTabPage.Controls.Add(this.textBoxReference);
            this.nasTabPage.Controls.Add(this.label9);
            this.nasTabPage.Controls.Add(this.textBoxLPP);
            this.nasTabPage.Controls.Add(this.label23);
            this.nasTabPage.Location = new System.Drawing.Point(4, 22);
            this.nasTabPage.Name = "nasTabPage";
            this.nasTabPage.Size = new System.Drawing.Size(575, 469);
            this.nasTabPage.TabIndex = 2;
            this.nasTabPage.Text = "NaS";
            this.nasTabPage.UseVisualStyleBackColor = true;
            // 
            // textBoxIdentifiers
            // 
            this.textBoxIdentifiers.Location = new System.Drawing.Point(121, 198);
            this.textBoxIdentifiers.Multiline = true;
            this.textBoxIdentifiers.Name = "textBoxIdentifiers";
            this.textBoxIdentifiers.ReadOnly = true;
            this.textBoxIdentifiers.Size = new System.Drawing.Size(184, 61);
            this.textBoxIdentifiers.TabIndex = 61;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(66, 201);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(52, 13);
            this.label43.TabIndex = 60;
            this.label43.Text = "Identifiers";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxParserIOVersion
            // 
            this.textBoxParserIOVersion.Location = new System.Drawing.Point(120, 68);
            this.textBoxParserIOVersion.Name = "textBoxParserIOVersion";
            this.textBoxParserIOVersion.ReadOnly = true;
            this.textBoxParserIOVersion.Size = new System.Drawing.Size(184, 20);
            this.textBoxParserIOVersion.TabIndex = 63;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(28, 71);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(86, 13);
            this.label44.TabIndex = 62;
            this.label44.Text = "ParserIO Version";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1131, 542);
            this.Controls.Add(this.textBoxParserIOVersion);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.textBoxIdentifiers);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.tabControlOutput);
            this.Controls.Add(this.textBoxAdditionalInformation);
            this.Controls.Add(this.labelAdditionalInformation);
            this.Controls.Add(this.textBoxExecuteResult);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.textBoxUDI);
            this.Controls.Add(this.labelUDI);
            this.Controls.Add(this.textBoxSymbologyID);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.textBoxcontainsOrMayContainId);
            this.Controls.Add(this.labelContainsProductId);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.textBoxCIP);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.textBoxFamily);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.textBoxACL);
            this.Controls.Add(this.ACL);
            this.Controls.Add(this.textBoxSerial);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.buttonParser);
            this.Controls.Add(this.textBoxNormalizedExpiry);
            this.Controls.Add(this.textBoxExpiry);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBoxLot);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBoxVariante);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxType);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxBarcode);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "ParserIO";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControlOutput.ResumeLayout(false);
            this.hibcTabPage.ResumeLayout(false);
            this.hibcTabPage.PerformLayout();
            this.gs1TabPage.ResumeLayout(false);
            this.gs1TabPage.PerformLayout();
            this.nasTabPage.ResumeLayout(false);
            this.nasTabPage.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox textBoxBarcode;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox textBoxType;
    private System.Windows.Forms.TextBox textBoxVariante;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.TextBox textBoxPCN;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.TextBox textBoxLIC;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.TextBox textBoxLot;
    private System.Windows.Forms.Label label10;
    private System.Windows.Forms.TextBox textBoxExpiry;
    private System.Windows.Forms.Label label11;
    private System.Windows.Forms.TextBox textBoxNormalizedExpiry;
    private System.Windows.Forms.Button buttonParser;
    private System.Windows.Forms.TextBox textBoxReference;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.TextBox textBoxUoM;
    private System.Windows.Forms.Label label12;
    private System.Windows.Forms.TextBox textBoxQuantity;
    private System.Windows.Forms.Label label17;
    private System.Windows.Forms.TextBox textBoxSerial;
    private System.Windows.Forms.Label label20;
    private System.Windows.Forms.MenuStrip menuStrip1;
    private System.Windows.Forms.ToolStripMenuItem testToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem aboutParserIOToolStripMenuItem;
    private System.Windows.Forms.TextBox textBoxACL;
    private System.Windows.Forms.Label ACL;
    private System.Windows.Forms.TextBox textBoxFamily;
    private System.Windows.Forms.Label label22;
    private System.Windows.Forms.TextBox textBoxLPP;
    private System.Windows.Forms.Label label23;
    private System.Windows.Forms.TextBox textBoxCIP;
    private System.Windows.Forms.Label label24;
    private System.Windows.Forms.TextBox textBoxNaS7;
    private System.Windows.Forms.Label label26;
    private System.Windows.Forms.Label label29;
    private System.Windows.Forms.Label labelContainsProductId;
    private System.Windows.Forms.TextBox textBoxcontainsOrMayContainId;
    private System.Windows.Forms.TextBox textBoxUPN;
    private System.Windows.Forms.Label label25;
    private System.Windows.Forms.TextBox textBoxSymbologyID;
    private System.Windows.Forms.Label label32;
    private System.Windows.Forms.TextBox textBoxNaSIdParamName;
    private System.Windows.Forms.Label labelNaSIdParamName;
    private System.Windows.Forms.TextBox textBoxUDI;
    private System.Windows.Forms.Label labelUDI;
        private System.Windows.Forms.TextBox textBoxExecuteResult;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBoxAdditionalInformation;
        private System.Windows.Forms.Label labelAdditionalInformation;
        private System.Windows.Forms.TextBox textBoxStorageLocation;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabControl tabControlOutput;
        private System.Windows.Forms.TabPage hibcTabPage;
        private System.Windows.Forms.TabPage gs1TabPage;
        private System.Windows.Forms.TextBox textBoxCUSTPARTNO;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBoxEAN;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBoxINTERNAL_99;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBoxINTERNAL_98;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBoxINTERNAL_97;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBoxINTERNAL_96;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBoxINTERNAL_95;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBoxINTERNAL_94;
        private System.Windows.Forms.TextBox textBoxPRODDATE;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBoxINTERNAL_93;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBoxINTERNAL_92;
        private System.Windows.Forms.TextBox textBoxNormalizedPRODDATE;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxINTERNAL_91;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxADDITIONALID;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBoxVARIANT;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBoxBESTBEFORE;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBoxCOUNT;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxNormalizedBESTBEFORE;
        private System.Windows.Forms.TextBox textBoxVARCOUNT;
        private System.Windows.Forms.TextBox textBoxCONTENT;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxSSCC;
        private System.Windows.Forms.TextBox textBoxGTIN;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage nasTabPage;
        private System.Windows.Forms.TextBox textBoxIdentifiers;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBoxParserIOVersion;
        private System.Windows.Forms.Label label44;
    }
}

